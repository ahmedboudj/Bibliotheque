﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblio
{
    internal abstract class Liste1
    {
        public static List<livre1> listLivre = new List<livre1>();
    }
}
