﻿namespace Biblio
{
    internal class EtudiantBase
    {
        private int ID;
    }
}